# Яна нашла СКИДКИ

Готовый минималистичный сайт для продвижения социальных сетей.

## Как запустить
Откройте `index.html` в браузере.

## Что изменить
Ссылки уже установлены:
- Telegram: https://t.me/sale_bambita (главный канал)
- YouTube: https://youtube.com/@sale_bambita
- MAX: https://max.ru/sale_bambita

Сайт полностью статический: HTML + CSS + JavaScript.
